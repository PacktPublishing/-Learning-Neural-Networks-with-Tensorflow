#!/bin/bash
jupyter notebook "$@" --NotebookApp.token='' --allow-root

